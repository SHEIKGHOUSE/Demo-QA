/**
 * 
 */
package in.amazon.Utilities;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

/**
 * @author Sheik
 *
 */
public class ExcelReadData {
	
	Workbook wb;
	Sheet sh;
	Row row;
	public ExcelReadData(String filepath) {
		
		try {
			FileInputStream fis=new FileInputStream(filepath);
			wb=WorkbookFactory.create(fis);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println("ReadData Exception"+e.getMessage());
		}
	}
	
	public String getExcelData(int Sheetnumber,int rowNumber,int ColNumber) {
		sh=wb.getSheetAt(0);
		String data=sh.getRow(rowNumber).getCell(ColNumber).getStringCellValue();
		return data;
	}

}
