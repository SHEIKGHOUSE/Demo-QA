package in.amazon.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import in.amazon.Utilities.ExcelReadData;

public class Registration extends BasePage{

	ExcelReadData readdata;
	WebDriver driver;
	public Registration() {
		super();
		//this.driver = driver;
	}
	
	@FindBy(xpath="//span[text()='Hello. Sign in']")
	 WebElement startregister;
	@FindBy(xpath="/descendant::a[text()='Start here.'][1]")
	 WebElement clickstart;
	@FindBy(xpath="//input[@name='customerName']")
	 WebElement name;
	@FindBy(xpath="//input[@placeholder='Mobile number']")
	WebElement mobilenumber;
	@FindBy(xpath="id=ap_email")
	WebElement email;
	@FindBy(name="password")
	WebElement password;
	@FindBy(id="continue")
	WebElement clickcontinue;
	@FindBy(name="code")
	WebElement code;
	
	public void amazonregistration() throws Exception {
		
        readdata=new ExcelReadData("./TestData/sheik.xlsx");
		WaitForObject(startregister);
		Actions act=new Actions(driver);
		act.moveToElement(startregister);
		startregister.click();
		//WaitForObject(clickstart);
		Thread.sleep(6000);
		clickstart.click();
		WaitForObject(name);
		name.sendKeys(readdata.getExcelData(0, 1, 0));
		mobilenumber.sendKeys(readdata.getExcelData(0, 1, 1));
		email.sendKeys(readdata.getExcelData(0, 1, 2));
		password.sendKeys(readdata.getExcelData(0, 1, 3));
		clickcontinue.click();
		
	}

}
